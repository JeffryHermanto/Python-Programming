def calc_shipping():
    pass


def calc_tax():
    pass


if __name__ == "__main__":
    print("Sales started")
    calc_tax()
